<?php

$con = mysqli_connect("sql213.infinityfree.com","if0_37874846","rQPiJugFHkROp","if0_37874846_tcu_canteen");

?>
