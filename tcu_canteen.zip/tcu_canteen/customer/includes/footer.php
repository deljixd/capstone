<footer class="footer_container">
  <div class="footer">

    <p class="copyright">
      &copy; <?php echo date("Y");?> TCU Canteen&trade;
    </p>

    <p class="group">Capstone 2 Project</p>

  </div>
</footer>