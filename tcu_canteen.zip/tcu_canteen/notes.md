# Admin Password

- Password@123

# all pages change of background-color or color

- hover buttons, table row, etc

# homepage

- nav and header styles (hover, colors, backgrounds) - done
- second nav links user and homepage - done

# product/item

- bookmark color change - done
- add wishlist - pending
- fix product image - done

# account user

- fix user table - done
- payment details of of all stalls - done
- new order at the top of list - done

# admin

- new admin user backend - pending
- remove unused "Show as Top Product Category" - done
- admin background color and other styles - done
- admin sidebar change "user" to "admin user" as well as the dropdown - done
